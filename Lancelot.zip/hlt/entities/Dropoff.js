'use strict';

const GameEntity = require('./GameEntity');

class Dropoff extends GameEntity {
}

module.exports = Dropoff;